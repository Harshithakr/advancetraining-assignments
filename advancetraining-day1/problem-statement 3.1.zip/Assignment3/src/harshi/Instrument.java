package harshi;

public abstract class Instrument {
	public abstract void play();
}
